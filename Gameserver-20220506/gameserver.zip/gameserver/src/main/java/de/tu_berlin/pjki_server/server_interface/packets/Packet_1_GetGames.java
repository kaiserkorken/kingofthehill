package de.tu_berlin.pjki_server.server_interface.packets;

public class Packet_1_GetGames extends AbstractPacket {

	public Packet_1_GetGames() {
		super(Type.GETGAMES);
	}

}
